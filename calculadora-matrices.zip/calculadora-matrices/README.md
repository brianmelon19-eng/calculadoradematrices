# 🧮 Calculadora de Matrices

Aplicación web profesional para realizar operaciones con matrices.

## ✨ Características

- ✅ Suma y resta de matrices
- ✅ Multiplicación de matrices
- ✅ Transpuesta
- ✅ Determinante
- ✅ Matriz inversa
- ✅ Multiplicación escalar
- ✅ Tema claro/oscuro
- ✅ Diseño responsive
- ✅ Solo números enteros

## 🚀 Cómo Usar

1. Abre `index.html` en tu navegador
2. Ajusta las dimensiones de las matrices con los botones +/-
3. Ingresa los valores en las celdas
4. Selecciona una operación
5. ¡Ve el resultado!

## 📁 Archivos

- `index.html` - Estructura de la aplicación
- `styles.css` - Estilos y diseño
- `script.js` - Lógica y operaciones

## 🌐 Compartir

Para compartir esta aplicación, puedes usar:
- GitHub Pages
- Netlify
- Vercel
- CodePen
- Replit

Solo necesitas subir los 3 archivos principales.

## 💡 Requisitos

- Navegador web moderno (Chrome, Firefox, Safari, Edge)
- JavaScript habilitado
- No requiere instalación

---

Hecho con ❤️ para cálculos matriciales
