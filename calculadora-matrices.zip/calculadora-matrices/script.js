// Estado global
let matrices = {
    A: { rows: 3, cols: 3, data: [] },
    B: { rows: 3, cols: 3, data: [] }
};

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
    initializeMatrices();
    loadTheme();
    setupThemeToggle();
});

// Inicializar matrices con valores por defecto
function initializeMatrices() {
    // Matriz A - Identidad
    matrices.A.data = [
        [1, 0, 0],
        [0, 1, 0],
        [0, 0, 1]
    ];
    
    // Matriz B - Ejemplo
    matrices.B.data = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]
    ];
    
    renderMatrix('A');
    renderMatrix('B');
}

// Cambiar dimensiones
function changeDimension(matrix, dimension, delta) {
    const current = matrices[matrix][dimension];
    const newValue = current + delta;
    
    if (newValue < 1 || newValue > 10) return;
    
    matrices[matrix][dimension] = newValue;
    document.getElementById(`${dimension}${matrix}`).textContent = newValue;
    
    // Redimensionar matriz
    const newData = [];
    for (let i = 0; i < matrices[matrix].rows; i++) {
        newData[i] = [];
        for (let j = 0; j < matrices[matrix].cols; j++) {
            newData[i][j] = (matrices[matrix].data[i] && matrices[matrix].data[i][j]) || 0;
        }
    }
    matrices[matrix].data = newData;
    
    renderMatrix(matrix);
}

// Renderizar matriz
function renderMatrix(matrix) {
    const container = document.getElementById(`matrix${matrix}`);
    const { rows, cols, data } = matrices[matrix];
    
    container.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
    container.innerHTML = '';
    
    for (let i = 0; i < rows; i++) {
        for (let j = 0; j < cols; j++) {
            const input = document.createElement('input');
            input.type = 'number';
            input.step = '1';
            input.value = Math.round(data[i][j]) || 0;
            input.addEventListener('change', (e) => {
                matrices[matrix].data[i][j] = parseInt(e.target.value) || 0;
            });
            container.appendChild(input);
        }
    }
}

// Operaciones matriciales
function calculate(operation) {
    try {
        let result;
        let steps = [];
        
        switch(operation) {
            case 'add':
                result = addMatrices();
                steps.push('Suma de matrices: C[i,j] = A[i,j] + B[i,j]');
                break;
            case 'subtract':
                result = subtractMatrices();
                steps.push('Resta de matrices: C[i,j] = A[i,j] - B[i,j]');
                break;
            case 'multiply':
                result = multiplyMatrices();
                steps.push('Multiplicación de matrices: C[i,j] = Σ(A[i,k] × B[k,j])');
                break;
            case 'transpose':
                result = transpose(matrices.A);
                steps.push('Transpuesta: intercambia filas por columnas');
                break;
            case 'determinant':
                result = determinant(matrices.A);
                steps.push('Determinante calculado usando cofactores');
                break;
            case 'inverse':
                result = inverse(matrices.A);
                steps.push('Matriz inversa calculada usando Gauss-Jordan');
                break;
            case 'scalar':
                const scalar = parseInt(document.getElementById('scalarInput').value) || 1;
                result = scalarMultiply(matrices.A, scalar);
                steps.push(`Multiplicación escalar: C[i,j] = ${scalar} × A[i,j]`);
                break;
        }
        
        displayResult(result, steps, true);
    } catch (error) {
        displayResult(null, [error.message], false);
    }
}

// Suma de matrices
function addMatrices() {
    const A = matrices.A;
    const B = matrices.B;
    
    if (A.rows !== B.rows || A.cols !== B.cols) {
        throw new Error(`Las matrices deben tener las mismas dimensiones. A es ${A.rows}×${A.cols}, B es ${B.rows}×${B.cols}`);
    }
    
    const result = { rows: A.rows, cols: A.cols, data: [] };
    for (let i = 0; i < A.rows; i++) {
        result.data[i] = [];
        for (let j = 0; j < A.cols; j++) {
            result.data[i][j] = Math.round(A.data[i][j] + B.data[i][j]);
        }
    }
    return result;
}

// Resta de matrices
function subtractMatrices() {
    const A = matrices.A;
    const B = matrices.B;
    
    if (A.rows !== B.rows || A.cols !== B.cols) {
        throw new Error(`Las matrices deben tener las mismas dimensiones. A es ${A.rows}×${A.cols}, B es ${B.rows}×${B.cols}`);
    }
    
    const result = { rows: A.rows, cols: A.cols, data: [] };
    for (let i = 0; i < A.rows; i++) {
        result.data[i] = [];
        for (let j = 0; j < A.cols; j++) {
            result.data[i][j] = Math.round(A.data[i][j] - B.data[i][j]);
        }
    }
    return result;
}

// Multiplicación de matrices
function multiplyMatrices() {
    const A = matrices.A;
    const B = matrices.B;
    
    if (A.cols !== B.rows) {
        throw new Error(`El número de columnas de A (${A.cols}) debe ser igual al número de filas de B (${B.rows})`);
    }
    
    const result = { rows: A.rows, cols: B.cols, data: [] };
    for (let i = 0; i < A.rows; i++) {
        result.data[i] = [];
        for (let j = 0; j < B.cols; j++) {
            let sum = 0;
            for (let k = 0; k < A.cols; k++) {
                sum += A.data[i][k] * B.data[k][j];
            }
            result.data[i][j] = Math.round(sum);
        }
    }
    return result;
}

// Transpuesta
function transpose(matrix) {
    const result = { rows: matrix.cols, cols: matrix.rows, data: [] };
    for (let i = 0; i < matrix.cols; i++) {
        result.data[i] = [];
        for (let j = 0; j < matrix.rows; j++) {
            result.data[i][j] = Math.round(matrix.data[j][i]);
        }
    }
    return result;
}

// Determinante
function determinant(matrix) {
    if (matrix.rows !== matrix.cols) {
        throw new Error(`La matriz debe ser cuadrada. La matriz es ${matrix.rows}×${matrix.cols}`);
    }
    
    const n = matrix.rows;
    const data = matrix.data.map(row => [...row]);
    
    if (n === 1) return data[0][0];
    if (n === 2) return data[0][0] * data[1][1] - data[0][1] * data[1][0];
    
    let det = 0;
    for (let j = 0; j < n; j++) {
        const subMatrix = [];
        for (let i = 1; i < n; i++) {
            const row = [];
            for (let k = 0; k < n; k++) {
                if (k !== j) row.push(data[i][k]);
            }
            subMatrix.push(row);
        }
        const sign = j % 2 === 0 ? 1 : -1;
        det += sign * data[0][j] * determinant({ rows: n-1, cols: n-1, data: subMatrix });
    }
    
    return Math.round(det);
}

// Matriz inversa
function inverse(matrix) {
    if (matrix.rows !== matrix.cols) {
        throw new Error(`La matriz debe ser cuadrada. La matriz es ${matrix.rows}×${matrix.cols}`);
    }
    
    const det = determinant(matrix);
    if (Math.abs(det) < 1e-10) {
        throw new Error('La matriz es singular (determinante = 0) y no tiene inversa');
    }
    
    const n = matrix.rows;
    const augmented = matrix.data.map((row, i) => {
        const newRow = [...row];
        for (let j = 0; j < n; j++) {
            newRow.push(i === j ? 1 : 0);
        }
        return newRow;
    });
    
    // Gauss-Jordan
    for (let i = 0; i < n; i++) {
        let maxRow = i;
        for (let k = i + 1; k < n; k++) {
            if (Math.abs(augmented[k][i]) > Math.abs(augmented[maxRow][i])) {
                maxRow = k;
            }
        }
        [augmented[i], augmented[maxRow]] = [augmented[maxRow], augmented[i]];
        
        const pivot = augmented[i][i];
        for (let j = 0; j < 2 * n; j++) {
            augmented[i][j] /= pivot;
        }
        
        for (let k = 0; k < n; k++) {
            if (k !== i) {
                const factor = augmented[k][i];
                for (let j = 0; j < 2 * n; j++) {
                    augmented[k][j] -= factor * augmented[i][j];
                }
            }
        }
    }
    
    const result = { rows: n, cols: n, data: [] };
    for (let i = 0; i < n; i++) {
        result.data[i] = augmented[i].slice(n).map(val => Math.round(val));
    }
    
    return result;
}

// Multiplicación escalar
function scalarMultiply(matrix, scalar) {
    const result = { rows: matrix.rows, cols: matrix.cols, data: [] };
    for (let i = 0; i < matrix.rows; i++) {
        result.data[i] = [];
        for (let j = 0; j < matrix.cols; j++) {
            result.data[i][j] = Math.round(matrix.data[i][j] * scalar);
        }
    }
    return result;
}

// Mostrar resultado
function displayResult(result, steps, success) {
    const container = document.getElementById('resultContainer');
    
    if (!success) {
        container.innerHTML = `
            <div class="result-error">
                <strong>❌ Error:</strong> ${steps[0]}
            </div>
        `;
        return;
    }
    
    let html = '<div class="result-success">';
    html += '<strong>✅ Resultado:</strong>';
    
    if (typeof result === 'number') {
        html += `<div class="result-scalar">${formatNumber(result)}</div>`;
    } else {
        html += '<div class="result-matrix" style="grid-template-columns: repeat(' + result.cols + ', 1fr);">';
        for (let i = 0; i < result.rows; i++) {
            for (let j = 0; j < result.cols; j++) {
                html += `<div class="cell">${formatNumber(result.data[i][j])}</div>`;
            }
        }
        html += '</div>';
    }
    
    if (steps.length > 0) {
        html += '<div class="result-steps"><strong>Pasos:</strong><br>' + steps.join('<br>') + '</div>';
    }
    
    html += '</div>';
    container.innerHTML = html;
}

// Formatear números
function formatNumber(num) {
    return Math.round(num).toString();
}

// Reiniciar matrices
function resetMatrices() {
    matrices.A.rows = 3;
    matrices.A.cols = 3;
    matrices.B.rows = 3;
    matrices.B.cols = 3;
    
    document.getElementById('rowsA').textContent = '3';
    document.getElementById('colsA').textContent = '3';
    document.getElementById('rowsB').textContent = '3';
    document.getElementById('colsB').textContent = '3';
    
    initializeMatrices();
    
    document.getElementById('resultContainer').innerHTML = 
        '<p class="result-placeholder">Selecciona una operación para ver el resultado</p>';
}

// Tema
function setupThemeToggle() {
    document.getElementById('themeToggle').addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
        const isDark = document.body.classList.contains('dark-mode');
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
        document.querySelector('.theme-icon').textContent = isDark ? '☀️' : '🌙';
    });
}

function loadTheme() {
    const theme = localStorage.getItem('theme');
    if (theme === 'dark') {
        document.body.classList.add('dark-mode');
        document.querySelector('.theme-icon').textContent = '☀️';
    }
}
